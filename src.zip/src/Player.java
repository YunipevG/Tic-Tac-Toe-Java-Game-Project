/**
* Lead Author(s):
* @author swapt; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-10-31
*/

/**
 * Purpose: The reponsibility of Player is ...
 *
 * Player is-a ...
 * Player is ...
 */

public class Player {
    private String name; // player's name for display or tracking
    private char symbol; // player's symbol ('X' or 'O') used on the board

    public Player(String name, char symbol) {
        this.name = name; // store player's name
        this.symbol = symbol; // store player's symbol
    }

    public String getName() {
        return name; // return the player's name
    }

    public char getSymbol() {
        return symbol; // return the player's symbol for moves
    }
}