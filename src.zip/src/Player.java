/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: The responsibility of Player is to represent a Tic Tac Toe player.
 * 
 * Player is-a class used to store player-specific information, including name and symbol.
 * Player is used by GameLogic to manage turns and moves.
 */
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Player implements Serializable {
    private String name;          // Player's display name
    private char symbol;          // 'X' or 'O'
    private List<int[]> moves;    // Optional: store moves {row, col}

    /**
     * Constructor to create a new player with a name and symbol.
     *
     * @param name   Player's name
     * @param symbol Symbol to use ('X' or 'O')
     */
    public Player(String name, char symbol) {
        this.name = name;
        if (symbol != 'X' && symbol != 'O') {
            throw new IllegalArgumentException("Symbol must be 'X' or 'O'");
        }
        this.symbol = symbol;
        this.moves = new ArrayList<>();
    }

    public String getName() {
        return name;
    }

    public char getSymbol() {
        return symbol;
    }

    /** Adds a move to the player's move history */
    public void addMove(int row, int col) {
        moves.add(new int[]{row, col});
    }

    /** Returns a copy of the player's move history */
    public List<int[]> getMoves() {
        return new ArrayList<>(moves);
    }

    /** Clears the player's move history (e.g., when restarting game) */
    public void resetMoves() {
        moves.clear();
    }

    @Override
    public String toString() {
        return name + " (" + symbol + ")";
    }
}
