/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: The responsibility of Player is to represent a Tic Tac Toe player.
 * 
 * Player is-a class used to store player-specific information, including name and symbol.
 * Player is used by GameLogic to manage turns and moves.
 */
public class Player {
    private String name;   // player's name for display or tracking
    private char symbol;   // player's symbol ('X' or 'O') used on the board

    /**
     * Constructor to create a new player with a name and symbol.
     *
     * @param name   the name of the player
     * @param symbol the symbol used by the player ('X' or 'O')
     */
    public Player(String name, char symbol) {
        this.name = name;
        this.symbol = symbol;
    }

    /**
     * Get the player's name.
     *
     * @return the name of the player
     */
    public String getName() {
        return name;
    }

    /**
     * Get the player's symbol.
     *
     * @return the symbol of the player ('X' or 'O')
     */
    public char getSymbol() {
        return symbol;
    }

    /**
     * Returns a string representation of the player (for debugging).
     *
     * @return the player's name and symbol as a string
     */
    @Override
    public String toString() {
        return name + " (" + symbol + ")";
    }
}
