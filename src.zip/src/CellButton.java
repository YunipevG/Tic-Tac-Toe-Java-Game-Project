/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: CellButton represents a single cell in the Tic Tac Toe grid.
 *
 * CellButton is-a JButton.
 * CellButton stores its row and column, the symbol (X/O), and provides methods
 * to update and reset its value.
 */

import javax.swing.JButton;

public class CellButton extends JButton {
    private int row; // row position on the board
    private int col; // column position on the board
    private char value; // current symbol in this cell ('X', 'O', or '\0')

    public CellButton(int row, int col) {
        this.row = row;
        this.col = col;
        this.value = '\0'; // initially empty
    }

    public int getRow() {
        return row;
    }

    public int getCol() {
        return col;
    }

    public char getValue() {
        return value;
    }

    /**
     * Sets the symbol for this cell and updates the button text.
     *
     * @param value 'X', 'O', or '\0' for empty
     */
    public void setValue(char value) {
        this.value = value;
        setText(value == '\0' ? "" : String.valueOf(value));
    }

    /**
     * Resets the cell to empty and clears the button text.
     * Used when restarting the game.
     */
    public void reset() {
        setValue('\0');
        setEnabled(true);
    }

    @Override
    public String toString() {
        return String.valueOf(value);
    }
}
