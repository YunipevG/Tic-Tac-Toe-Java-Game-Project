/**
* Lead Author(s):
* @author swapt; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-10-31
*/

/**
 * Purpose: The reponsibility of CellButton is ...
 *
 * CellButton is-a ...
 * CellButton is ...
 */

import javax.swing.JButton;

public class CellButton extends JButton {
    private int row; // row position on the board
    private int col; // column position on the board
    private char value; // current symbol in this cell ('X', 'O', or '\0')

    public CellButton(int row, int col) {
        this.row = row; // store row
        this.col = col; // store column
        this.value = '\0'; // initially empty
    }

    public int getRow() {
        return row; // return row index
    }

    public int getCol() {
        return col; // return column index
    }

    public char getValue() {
        return value; // return current symbol
    }

    public void setValue(char value) {
        this.value = value; // set symbol for this cell
        setText(value == '\0' ? "" : String.valueOf(value)); // update button text
    }

    @Override
    public String toString() {
        return String.valueOf(value); // display symbol for debugging
    }
}