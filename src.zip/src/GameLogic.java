/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: GameLogic manages the Tic Tac Toe board state, validates moves, checks
 * for wins or ties, and handles switching player turns.
 *
 * GameLogic is-a standard Java class.
 * GameLogic is used by TicTacToeGUI to control gameplay logic.
 */

public class GameLogic {
    private char[][] board; // 3x3 board where moves are stored
    private Player currentPlayer;
    private Player player1;
    private Player player2;

    public GameLogic(Player p1, Player p2) {
        player1 = p1;
        player2 = p2;
        currentPlayer = player1;
        board = new char[3][3]; // empty board
    }

    /**
     * Attempts to place the current player's symbol at the specified position.
     * @param row Row index (0-2)
     * @param col Column index (0-2)
     * @return true if move was successful, false if cell is occupied or invalid
     */
    public boolean makeMove(int row, int col) {
        try {
            if (board[row][col] == '\0') {
                board[row][col] = currentPlayer.getSymbol();
                return true;
            }
        } catch (ArrayIndexOutOfBoundsException e) {
            System.err.println("Invalid move: (" + row + "," + col + ")");
        }
        return false;
    }

    /** Checks if the current player has won. */
    public boolean checkWin() {
        return getWinningCells() != null;
    }

    /**
     * Returns the winning cells as {{row,col},{row,col},{row,col}}, or null if no winner.
     * @return array of winning cell positions or null
     */
    public int[][] getWinningCells() {
        char s = currentPlayer.getSymbol();

        // Check rows and columns
        for (int i = 0; i < 3; i++) {
            if (board[i][0] == s && board[i][1] == s && board[i][2] == s)
                return new int[][]{{i,0},{i,1},{i,2}};
            if (board[0][i] == s && board[1][i] == s && board[2][i] == s)
                return new int[][]{{0,i},{1,i},{2,i}};
        }

        // Check diagonals
        if (board[0][0] == s && board[1][1] == s && board[2][2] == s)
            return new int[][]{{0,0},{1,1},{2,2}};
        if (board[0][2] == s && board[1][1] == s && board[2][0] == s)
            return new int[][]{{0,2},{1,1},{2,0}};

        return null;
    }

    /** Checks if the game is a tie (board full and no winner). */
    public boolean isTie() {
        for (char[] row : board) {
            for (char c : row) {
                if (c == '\0') return false;
            }
        }
        return !checkWin();
    }

    /** Switches the current player to the other player. */
    public void switchTurn() {
        currentPlayer = (currentPlayer == player1) ? player2 : player1;
    }

    /** Returns the current player. */
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    /** Returns the current board state. */
    public char[][] getBoard() {
        return board;
    }

    /** Resets the game board to empty and sets current player to player1. */
    public void reset() {
        board = new char[3][3];
        currentPlayer = player1;
    }

    /** Prints the board to console (for testing/debugging). */
    public void printBoard() {
        for (char[] row : board) {
            for (char c : row) {
                System.out.print((c == '\0' ? '-' : c) + " ");
            }
            System.out.println();
        }
    }
}
