/**
* Lead Author(s):
* @author swapt; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-10-31
*/

/**
 * Purpose: The reponsibility of GameLogic is ...
 *
 * GameLogic is-a ...
 * GameLogic is ...
 */

public class GameLogic {
    private char[][] board; // 3x3 board where moves are stored
    private Player currentPlayer; // whose turn it is now
    private Player player1; // first player
    private Player player2; // second player

    public GameLogic(Player p1, Player p2) {
        player1 = p1; // assign first player
        player2 = p2; // assign second player
        currentPlayer = player1; // start with player 1
        board = new char[3][3]; // initialize empty board
    }

    // Place the current player's symbol in the specified cell
    public boolean makeMove(int row, int col) {
        if (board[row][col] == '\0') { // check if cell is empty
            board[row][col] = currentPlayer.getSymbol(); // place symbol
            return true; // move successful
        }
        return false; // cell already filled
    }

    // Check if the current player has won
    public boolean checkWin() {
        char s = currentPlayer.getSymbol();

        // Check rows and columns
        for (int i = 0; i < 3; i++) {
            if ((board[i][0] == s && board[i][1] == s && board[i][2] == s) ||
                (board[0][i] == s && board[1][i] == s && board[2][i] == s)) {
                return true;
            }
        }

        // Check diagonals
        if ((board[0][0] == s && board[1][1] == s && board[2][2] == s) ||
            (board[0][2] == s && board[1][1] == s && board[2][0] == s)) {
            return true;
        }

        return false;
    }

    // Check if the game is a tie (board full and no winner)
    public boolean isTie() {
        for (char[] row : board) {
            for (char c : row) {
                if (c == '\0') return false; // empty cell found
            }
        }
        return !checkWin(); // tie if full board and no winner
    }

    // Switch the current player
    public void switchTurn() {
        currentPlayer = (currentPlayer == player1) ? player2 : player1;
    }

    // Get the current player
    public Player getCurrentPlayer() {
        return currentPlayer;
    }

    // Get the current board state
    public char[][] getBoard() {
        return board;
    }

    // Optional: display board in console for testing
    public void printBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                System.out.print((board[i][j] == '\0' ? '-' : board[i][j]) + " ");
            }
            System.out.println();
        }
    }
}