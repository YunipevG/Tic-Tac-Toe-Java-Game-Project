/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: GameLogicTest provides a console-based interface to test the
 * GameLogic class, including moves, win detection, tie detection, and turn switching.
 *
 * GameLogicTest is-a Java console application.
 * GameLogicTest is used to verify that the Tic Tac Toe logic works correctly before GUI integration.
 */

import java.util.InputMismatchException;
import java.util.Scanner;

public class GameLogicTest {
    public static void main(String[] args) {
        Player p1 = new Player("Player 1", 'X');
        Player p2 = new Player("Player 2", 'O');
        GameLogic game = new GameLogic(p1, p2);

        Scanner scanner = new Scanner(System.in);
        boolean gameEnded = false;

        System.out.println("=== Tic Tac Toe GameLogic Test ===");
        printBoard(game.getBoard());

        while (!gameEnded) {
            Player current = game.getCurrentPlayer();
            System.out.println(current.getName() + "'s turn (" + current.getSymbol() + ")");

            int row = -1, col = -1;
            boolean validInput = false;

            while (!validInput) {
                try {
                    System.out.print("Enter row (0-2): ");
                    row = scanner.nextInt();
                    System.out.print("Enter column (0-2): ");
                    col = scanner.nextInt();

                    if (row < 0 || row > 2 || col < 0 || col > 2) {
                        System.out.println("Invalid input! Row and column must be between 0 and 2.");
                    } else if (!game.makeMove(row, col)) {
                        System.out.println("Cell already taken! Choose another.");
                    } else {
                        validInput = true; // move was successful
                    }
                } catch (InputMismatchException e) {
                    System.out.println("Invalid input! Please enter numbers 0, 1, or 2.");
                    scanner.next(); // clear invalid input
                }
            }

            printBoard(game.getBoard());

            if (game.checkWin()) {
                System.out.println("Congratulations! " + current.getName() + " wins!");
                highlightWinningLine(game);
                gameEnded = true;
            } else if (game.isTie()) {
                System.out.println("It's a tie!");
                gameEnded = true;
            } else {
                game.switchTurn();
            }
        }

        scanner.close();
        System.out.println("Game over.");
    }

    private static void printBoard(char[][] board) {
        System.out.println("\nCurrent Board:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                char c = board[i][j];
                System.out.print((c == '\0' ? '-' : c) + " ");
            }
            System.out.println();
        }
        System.out.println();
    }

    /** Prints the winning line coordinates for testing purposes */
    private static void highlightWinningLine(GameLogic game) {
        int[][] cells = game.getWinningCells();
        if (cells != null) {
            System.out.println("Winning line at: ");
            for (int[] cell : cells) {
                System.out.println("(" + cell[0] + "," + cell[1] + ")");
            }
        }
    }
}
