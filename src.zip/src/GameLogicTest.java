/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: GameLogicTest provides a console-based interface to test the
 * GameLogic class, including moves, win detection, tie detection, and turn switching.
 *
 * GameLogicTest is-a Java console application.
 * GameLogicTest is used to verify that the Tic Tac Toe logic works correctly before GUI integration.
 */

import java.util.Scanner;

public class GameLogicTest {
    public static void main(String[] args) {
        // create two players
        Player p1 = new Player("Player 1", 'X');
        Player p2 = new Player("Player 2", 'O');

        // create game logic instance
        GameLogic game = new GameLogic(p1, p2);

        Scanner scanner = new Scanner(System.in);
        boolean gameEnded = false;

        System.out.println("=== Tic Tac Toe GameLogic Test ===");
        printBoard(game.getBoard());

        // game loop
        while (!gameEnded) {
            Player current = game.getCurrentPlayer();
            System.out.println(current.getName() + "'s turn (" + current.getSymbol() + ")");
            System.out.print("Enter row (0-2): ");
            int row = scanner.nextInt();
            System.out.print("Enter column (0-2): ");
            int col = scanner.nextInt();

            // attempt to make move
            if (game.makeMove(row, col)) {
                printBoard(game.getBoard());

                if (game.checkWin()) {
                    System.out.println("Congratulations! " + current.getName() + " wins!");
                    gameEnded = true;
                } else if (game.isTie()) {
                    System.out.println("It's a tie!");
                    gameEnded = true;
                } else {
                    game.switchTurn(); // continue to next player
                }
            } else {
                System.out.println("Invalid move! Cell already taken. Try again.");
            }
        }

        scanner.close();
        System.out.println("Game over.");
    }

    /**
     * Helper method to display the current board state in the console.
     * Empty cells are represented by '-'.
     *
     * @param board the 3x3 character array representing the board
     */
    private static void printBoard(char[][] board) {
        System.out.println("\nCurrent Board:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                char c = board[i][j];
                System.out.print((c == '\0' ? '-' : c) + " ");
            }
            System.out.println();
        }
        System.out.println();
    }
}
