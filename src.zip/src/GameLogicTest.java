/**
* Lead Author(s):
* @author swapt; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-10-31
*/

/**
 * Purpose: The reponsibility of GameLogicTest is ...
 *
 * GameLogicTest is-a ...
 * GameLogicTest is ...
 */

import java.util.Scanner;

public class GameLogicTest {
    public static void main(String[] args) {
        // create two players
        Player p1 = new Player("Player 1", 'X');
        Player p2 = new Player("Player 2", 'O');

        // create game logic instance
        GameLogic game = new GameLogic(p1, p2);

        Scanner scanner = new Scanner(System.in);
        boolean gameEnded = false;

        System.out.println("Tic Tac Toe GameLogic Test");
        printBoard(game.getBoard());

        // game loop
        while (!gameEnded) {
            Player current = game.getCurrentPlayer();
            System.out.println(current.getName() + "'s turn (" + current.getSymbol() + ")");
            System.out.print("Enter row (0-2): ");
            int row = scanner.nextInt();
            System.out.print("Enter column (0-2): ");
            int col = scanner.nextInt();

            // attempt to make move
            if (game.makeMove(row, col)) {
                printBoard(game.getBoard());

                if (game.checkWin()) {
                    System.out.println(current.getName() + " wins!");
                    gameEnded = true;
                } else if (game.isTie()) {
                    System.out.println("It's a tie!");
                    gameEnded = true;
                } else {
                    game.switchTurn(); // continue to next player
                }
            } else {
                System.out.println("Invalid move! Cell already taken, try again.");
            }
        }

        scanner.close();
        System.out.println("Game over.");
    }

    // helper method to display the board
    private static void printBoard(char[][] board) {
        System.out.println("Current Board:");
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                char c = board[i][j];
                System.out.print((c == '\0' ? '-' : c) + " "); // '-' represents empty cell
            }
            System.out.println();
        }
        System.out.println();
    }
}