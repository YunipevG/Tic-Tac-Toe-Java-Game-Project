/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: ControlPanel manages the Restart and Exit buttons for Tic Tac Toe.
 *
 * ControlPanel is-a JPanel.
 * ControlPanel is used by TicTacToeGUI to allow the user to restart or exit the game.
 */

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Font;

public class ControlPanel extends JPanel {
    private JButton restartButton;
    private JButton exitButton;

    public ControlPanel(ActionListener restartListener, ActionListener exitListener) {
        // FlowLayout with horizontal gap for spacing
        setLayout(new FlowLayout(FlowLayout.CENTER, 20, 10));

        // Initialize Restart button
        restartButton = new JButton("Restart Game");
        restartButton.setPreferredSize(new Dimension(140, 40));
        restartButton.setFont(new Font("Arial", Font.BOLD, 14));
        addSafeListener(restartButton, restartListener);
        add(restartButton);

        // Initialize Exit button
        exitButton = new JButton("Exit Game");
        exitButton.setPreferredSize(new Dimension(140, 40));
        exitButton.setFont(new Font("Arial", Font.BOLD, 14));
        addSafeListener(exitButton, exitListener);
        add(exitButton);
    }

    /** Safely adds an ActionListener with exception handling */
    private void addSafeListener(JButton button, ActionListener listener) {
        button.addActionListener(e -> {
            try {
                listener.actionPerformed(e);
            } catch (Exception ex) {
                System.err.println("Error executing action on button '" + button.getText() + "': " + ex.getMessage());
            }
        });
    }

    /** Returns the Restart button. */
    public JButton getRestartButton() {
        return restartButton;
    }

    /** Returns the Exit button. */
    public JButton getExitButton() {
        return exitButton;
    }
}
