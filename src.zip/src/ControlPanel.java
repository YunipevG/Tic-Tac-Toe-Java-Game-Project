/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: ControlPanel manages the Restart and Exit buttons for Tic Tac Toe.
 *
 * ControlPanel is-a JPanel.
 * ControlPanel is used by TicTacToeGUI to allow the user to restart or exit the game.
 */

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.event.ActionListener;
import java.awt.FlowLayout;

public class ControlPanel extends JPanel {
    private JButton restartButton;
    private JButton exitButton;

    public ControlPanel(ActionListener restartListener, ActionListener exitListener) {
        setLayout(new FlowLayout());

        restartButton = new JButton("Restart Game");
        restartButton.addActionListener(restartListener);
        add(restartButton);

        exitButton = new JButton("Exit Game");
        exitButton.addActionListener(exitListener);
        add(exitButton);
    }

    /**
     * Returns the Restart button.
     */
    public JButton getRestartButton() {
        return restartButton;
    }

    /**
     * Returns the Exit button.
     */
    public JButton getExitButton() {
        return exitButton;
    }
}
