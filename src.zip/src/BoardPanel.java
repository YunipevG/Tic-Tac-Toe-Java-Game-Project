/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: BoardPanel manages the 3x3 grid of CellButtons for Tic Tac Toe.
 *
 * BoardPanel is-a JPanel.
 * BoardPanel is used by TicTacToeGUI to display and control the game board.
 */

import javax.swing.JPanel;
import java.awt.GridLayout;
import java.awt.Color;

public class BoardPanel extends JPanel {
    private CellButton[][] buttons; // 3x3 array to hold buttons

    public BoardPanel() {
        setLayout(new GridLayout(3, 3, 5, 5)); // 3x3 grid with 5px gaps
        buttons = new CellButton[3][3];

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new CellButton(i, j);
                add(buttons[i][j]);
            }
        }
    }

    /** Returns the 2D array of CellButtons. */
    public CellButton[][] getButtons() {
        return buttons;
    }

    /** Resets all buttons to empty, enables them, and clears highlights. */
    public void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                try {
                    buttons[i][j].reset();
                } catch (Exception e) {
                    System.err.println("Error resetting cell at (" + i + "," + j + "): " + e.getMessage());
                }
            }
        }
    }

    /**
     * Highlights the winning cells in a given color.
     * Safely handles null or out-of-bounds input.
     *
     * @param cells array of {row, col} positions to highlight
     * @param color the highlight color
     */
    public void highlightWinningCells(int[][] cells, Color color) {
        if (cells == null) return;
        for (int[] pos : cells) {
            try {
                int row = pos[0];
                int col = pos[1];
                if (row >= 0 && row < 3 && col >= 0 && col < 3) {
                    buttons[row][col].highlight(color);
                }
            } catch (Exception e) {
                System.err.println("Error highlighting cell: " + e.getMessage());
            }
        }
    }

    /** Clears any highlighted cells (used when restarting). */
    public void clearHighlights() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                try {
                    buttons[i][j].setBackground(null);
                } catch (Exception e) {
                    System.err.println("Error clearing highlight at (" + i + "," + j + "): " + e.getMessage());
                }
            }
        }
    }
}