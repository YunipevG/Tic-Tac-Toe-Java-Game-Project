/**
* Lead Author(s):
* @author swapt; student ID
* @author Full name; student ID
* <<Add additional lead authors here>>
*
* Other Contributors:
* Full name; student ID or contact information if not in class
* <<Add additional contributors (mentors, tutors, friends) here, with contact information>>
*
* References:
* Morelli, R., & Walde, R. (2016).
* Java, Java, Java: Object-Oriented Problem Solving
* https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
*
* <<Add more references here>>
*
* Version: 2025-10-31
*/

/**
 * Purpose: The reponsibility of BoardPanel is ...
 *
 * BoardPanel is-a ...
 * BoardPanel is ...
 */

import javax.swing.JPanel;
import java.awt.GridLayout;

public class BoardPanel extends JPanel {
    private CellButton[][] buttons; // 3x3 array to hold buttons

    public BoardPanel() {
        setLayout(new GridLayout(3, 3)); // 3x3 grid layout
        buttons = new CellButton[3][3]; // initialize button array

        // create each button and add it to the panel
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new CellButton(i, j); // new button
                add(buttons[i][j]); // add button to the panel
            }
        }
    }

    public CellButton[][] getButtons() {
        return buttons; // return button array for GUI control
    }
}