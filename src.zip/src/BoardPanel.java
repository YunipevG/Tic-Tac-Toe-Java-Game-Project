/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: BoardPanel manages the 3x3 grid of CellButtons for Tic Tac Toe.
 *
 * BoardPanel is-a JPanel.
 * BoardPanel is used by TicTacToeGUI to display and control the game board.
 */

import javax.swing.JPanel;
import java.awt.GridLayout;

public class BoardPanel extends JPanel {
    private CellButton[][] buttons; // 3x3 array to hold buttons

    public BoardPanel() {
        setLayout(new GridLayout(3, 3)); // 3x3 grid layout
        buttons = new CellButton[3][3]; // initialize button array

        // create each button and add it to the panel
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j] = new CellButton(i, j); // new button
                add(buttons[i][j]); // add button to the panel
            }
        }
    }

    /**
     * Returns the 2D array of CellButtons.
     * Used to add listeners and update board.
     */
    public CellButton[][] getButtons() {
        return buttons;
    }

    /**
     * Resets all buttons to empty and re-enables them.
     * Used when restarting the game.
     */
    public void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                buttons[i][j].setValue('\0'); // clear symbol
                buttons[i][j].setEnabled(true); // enable button
            }
        }
    }
}
