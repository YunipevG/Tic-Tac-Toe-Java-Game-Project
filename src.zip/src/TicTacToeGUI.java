/**
 * Lead Author(s):
 * @author swapt; student ID
 * @author Full name; student ID
 *
 * Other Contributors:
 * Full name; student ID or contact information if not in class
 *
 * References:
 * Morelli, R., & Walde, R. (2016).
 * Java, Java, Java: Object-Oriented Problem Solving
 * https://open.umn.edu/opentextbooks/textbooks/java-java-java-object-oriented-problem-solving
 *
 * Version: 2025-11-14
 */

/**
 * Purpose: The responsibility of TicTacToeGUI is to display the game window,
 * handle user input, and connect the board to GameLogic.
 *
 * TicTacToeGUI is-a JFrame.
 * TicTacToeGUI uses BoardPanel, ControlPanel, GameLogic, and Player to manage the game.
 */

import javax.swing.*;
import java.awt.*;

public class TicTacToeGUI extends JFrame {
    private GameLogic game;
    private BoardPanel boardPanel;
    private ControlPanel controlPanel;
    private JLabel statusLabel;

    public TicTacToeGUI() {
        // Create players and game logic
        Player p1 = new Player("Player 1", 'X');
        Player p2 = new Player("Player 2", 'O');
        game = new GameLogic(p1, p2);

        // Setup JFrame
        setTitle("Tic Tac Toe");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout(10, 10));
        getContentPane().setBackground(Color.WHITE);

        // Status label
        statusLabel = new JLabel(p1.getName() + "'s turn (" + p1.getSymbol() + ")");
        statusLabel.setHorizontalAlignment(SwingConstants.CENTER);
        statusLabel.setFont(new Font("Arial", Font.BOLD, 18));
        statusLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(statusLabel, BorderLayout.NORTH);

        // Board panel
        boardPanel = new BoardPanel();
        boardPanel.setBackground(Color.LIGHT_GRAY);
        add(boardPanel, BorderLayout.CENTER);

        // Control panel
        controlPanel = new ControlPanel(
            e -> restartGame(),
            e -> System.exit(0)
        );
        controlPanel.setBackground(Color.WHITE);
        add(controlPanel, BorderLayout.SOUTH);

        addButtonListeners();

        pack();
        setLocationRelativeTo(null);
        setVisible(true);
    }

    /** Add ActionListeners to all buttons on the board. */
    private void addButtonListeners() {
        for (CellButton[] row : boardPanel.getButtons()) {
            for (CellButton button : row) {
                button.addActionListener(e -> {
                    try {
                        Player current = game.getCurrentPlayer();
                        int rowIdx = button.getRow();
                        int colIdx = button.getCol();

                        if (game.makeMove(rowIdx, colIdx)) {
                            button.setValue(current.getSymbol());
                            current.addMove(rowIdx, colIdx); // log move

                            int[][] winningCells = game.getWinningCells();
                            if (winningCells != null) {
                                boardPanel.highlightWinningCells(winningCells, Color.GREEN);
                                JOptionPane.showMessageDialog(this,
                                        current.getName() + " wins!",
                                        "Game Over",
                                        JOptionPane.INFORMATION_MESSAGE);
                                disableBoard();
                            } else if (game.isTie()) {
                                JOptionPane.showMessageDialog(this,
                                        "It's a tie!",
                                        "Game Over",
                                        JOptionPane.INFORMATION_MESSAGE);
                                disableBoard();
                            } else {
                                game.switchTurn();
                                statusLabel.setText(game.getCurrentPlayer().getName() +
                                        "'s turn (" + game.getCurrentPlayer().getSymbol() + ")");
                            }
                        } else {
                            JOptionPane.showMessageDialog(this,
                                    "Invalid move! Cell already taken.",
                                    "Warning",
                                    JOptionPane.WARNING_MESSAGE);
                        }
                    } catch (Exception ex) {
                        JOptionPane.showMessageDialog(this,
                                "An error occurred: " + ex.getMessage(),
                                "Error",
                                JOptionPane.ERROR_MESSAGE);
                    }
                });
            }
        }
    }

    /** Disable all board buttons. */
    private void disableBoard() {
        for (CellButton[] row : boardPanel.getButtons()) {
            for (CellButton button : row) {
                button.setEnabled(false);
            }
        }
    }

    /** Restart the game. */
    private void restartGame() {
        game.getCurrentPlayer().resetMoves();
        game = new GameLogic(new Player("Player 1", 'X'), new Player("Player 2", 'O'));
        boardPanel.resetBoard();
        statusLabel.setText(game.getCurrentPlayer().getName() +
                "'s turn (" + game.getCurrentPlayer().getSymbol() + ")");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(TicTacToeGUI::new);
    }
}
